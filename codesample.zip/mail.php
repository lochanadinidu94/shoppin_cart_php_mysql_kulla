<html xmlns="http://www.w3.org/1999/html">
<body style="margin-left: auto; margin-right: auto; margin-top: 0px;  display: block; ">

<div style="width: 100%; height: 8px; background: #5e5e5e; display: block;"></div>


<div style="width: 80%; margin-right: auto; margin-left: auto; height: 1px; background: #ccc; "></div>

<div class="hello" style="width: 70%; margin-left: auto; margin-right: auto; font-size: 20px; padding: 40px 0 0; color: #555;">
    Hi,
</div>

<div style="width: 65%; margin-right: auto; margin-left: auto; padding: 20px 0 40px; text-align: justify; font-size: 18px; color: #555;">
    You have a new email form '.$name.'.
</div>

<div style="width: 100%; background: #eaeaea; height: auto; padding: 40px 0; text-align: center;">
    <table style="margin-left: auto; margin-right: auto; font-size: 20px; color: #555;">
        <tr>
            <td style="text-align: left">Name</td>
            <td>:</td>
            <td style="text-align: left">'.$name.'</td>
        </tr>

        <tr>
            <td style="text-align: left">Gender</td>
            <td>:</td>
            <td style="text-align: left">'.$name.'</td>
        </tr>

        <tr>
            <td style="text-align: left">Address</td>
            <td>:</td>
            <td style="text-align: left">'.$email.'</td>
        </tr>

        <tr>
            <td style="text-align: left">Email</td>
            <td>:</td>
            <td style="text-align: left">'.$email.'</td>
        </tr>

        <tr>
            <td style="text-align: left">Tel</td>
            <td>:</td>
            <td style="text-align: left">'.$telephone.'</td>
        </tr>
    </table>
</div>


<div style="color: #555; text-align: center; font-size: 20px; padding: 40px 0 20px;">
    Orders
</div>


<table style="margin-left: auto; margin-right: auto; font-size: 15px; color: #555;">
    <tr>
        <th style="text-align: left; padding: 5px; border: 1px solid #ccc;">Product ID</th>
        <th style="text-align: left; padding: 5px; border: 1px solid #ccc;">Product Name</th>
        <th style="text-align: left; padding: 5px; border: 1px solid #ccc;">Quantity</th>
        <th style="text-align: left; padding: 5px; border: 1px solid #ccc;">Price (1)</th>
        <th style="text-align: left; padding: 5px; border: 1px solid #ccc;">Date Ordered</th>
    </tr>


    <tr>
        <td style="text-align: left; padding: 5px; border: 1px solid #ccc;">1</td>
        <td style="text-align: left; padding: 5px; border: 1px solid #ccc;">dsg skgjhdkjshgks </td>
        <td style="text-align: left; padding: 5px; border: 1px solid #ccc;">1</td>
        <td style="text-align: left; padding: 5px; border: 1px solid #ccc;">1</td>
        <td style="text-align: left; padding: 5px; border: 1px solid #ccc;">1</td>
    </tr>

</table>





</div>
</body>
</html>