<div class="menu2">
            <ul class="">
                <li><a href="products.php?cat=InitialProducts">Foods & Essential Goods</a></li>
                <li><a href="products.php?cat=PersonalCareToiletries">Personal Care & Toiletries</a></li>
                <li><a href="products.php?cat=BabyCare">Baby Products</a></li>
                <li><a href="products.php?cat=HomeCareCleaning">Home Care & Cleaning</a></li>
                <li><a href="products.php?cat=FrozenChilledfoods">Frozen & Chilled foods</a></li>
                <li><a href="products.php?cat=StationeriesSchoolItems">Books-Stationery & School Item</a></li>
                <li><a href="products.php?cat=ElectricElectronics">Electric & Electronics</a></li>
                <li><a href="products.php?cat=VegetableFruit">Vegetable & Fruit</a></li>
                <li><a href="products.php?cat=BillPayment">Bill Payment</a></li>
                <li><a href="products.php?cat=Other">Other</a></li>
            </ul>
        </div>
