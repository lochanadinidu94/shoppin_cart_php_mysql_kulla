<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="assets/css/myStyle.css">
<link rel="stylesheet" href="assets/css/mediaQuery.css">
<link rel="stylesheet" href="assets/css/bootstrap.css">
<link rel="stylesheet" href="assets/css/bootstrap-theme.css">


<script src="assets/js/jquery-2.2.0.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="admin/js/my_notifications.js"></script>
<script src="assets/js/jquery.matchHeight-min.js"></script>
