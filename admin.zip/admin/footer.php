<footer>
  <div class="pull-right">
    <span align="center" style="color:grey;">ALL RIGHTS RESERVED @ 2017
  </div>
  <div class="clearfix"></div>
</footer>
